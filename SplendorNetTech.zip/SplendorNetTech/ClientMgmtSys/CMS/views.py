from django.shortcuts import render, redirect, get_object_or_404
from .forms import ClientForm
from .models import Client


# Create your views here.

def client_list(request):
    clients = Client.objects.all()
    query = request.GET.get('q')
    status_filter = request.GET.get('status')
    project_domain_filter = request.GET.get('project_domain')

    if query:
        clients = clients.filter(name__icontains=query) | clients.filter(company__icontains=query) | clients.filter(
            department__icontains=query)

    if status_filter:
        clients = clients.filter(status=status_filter)

    if project_domain_filter:
        clients = clients.filter(project_domain=project_domain_filter)

    template_name = 'client/client_list.html'
    context = {'clients': clients}
    return render(request, template_name, context)


def add_client(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('client_list')
    else:
        form = ClientForm()
    template_name = 'client/add_client.html'
    context = {'form': form}
    return render(request, template_name, context)


def client_detail(request, pk):
    client = get_object_or_404(Client, pk=pk)
    template_name = 'client/client_detail.html'
    context = {'client':client}
    return render(request, template_name, context)


def update_client(request,pk):
    client = get_object_or_404(Client, pk=pk)
    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            return redirect('client_list')
    else:
        form = ClientForm(instance=client)

    template_name = 'client/delete_client.html'
    context = {'form': form}
    return render(request, template_name, context)


def delete_client(request,pk):
    client = get_object_or_404(Client, pk=pk)
    if request.method == 'POST':
        client.delete()
        return redirect('client_list')
    template_name = 'client/delete_client.html'
    context = {'client': client}
    return render(request, template_name, context)














