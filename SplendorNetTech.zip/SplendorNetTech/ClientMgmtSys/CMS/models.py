from django.db import models


# Create your models here.
class Client(models.Model):

    STATUS_CHOICES = [
        ('Onboarded', 'Onboarded'),
        ('Not Onboarded', 'Not Onboarded'),
    ]

    PROJECT_DOMAIN = [
        ('SAAS', 'SAAS'),
        ('Ecommerce', 'Ecommerce'),
        ('CRM', 'CRM'),
        ('EPR', 'EPR'),
        ('Finance', 'Finance'),
    ]

    name = models.CharField(max_length=100)
    company = models.CharField(max_length=50)
    email_id = models.EmailField(unique=True)
    department = models.CharField(max_length=50)
    date_of_joining = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    project_domain = models.CharField(max_length=50, choices=PROJECT_DOMAIN)

