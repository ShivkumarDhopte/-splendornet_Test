from django.urls import include, path
from .views import add_client, update_client, delete_client, client_list, client_detail


urlpatterns = [
    path('', client_list, name='client_list'),
    path('client/<int:pk>/', client_detail, name='client_detail'),
    path('client/new/', add_client, name='add_client'),
    path('client/edit/<int:pk>/', update_client, name='update_client'),
    path('client/delete/<int:pk>/', delete_client, name='delete_client'),
]
